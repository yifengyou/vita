/* $OpenBSD: version.h,v 1.65 2012/07/22 18:19:21 markus Exp $ */

#define SSH_VERSION	"OpenSSH_6.1"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
